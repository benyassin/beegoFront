const pageMenus = [{
  'icon': 'fa fa-th-large',
  'title': 'Home',
  'url': '/home'
}, {
  'icon': 'fa fa-align-left',
  'title': 'Campaigns',
  'url': '/campaigns',
}, {
  'icon': 'fa fa-th-large',
  'title': 'Users',
  'url': '/users'
}];


export default pageMenus;
