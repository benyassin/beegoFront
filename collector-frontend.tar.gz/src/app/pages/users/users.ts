import { Component, OnInit  } from '@angular/core';

@Component({
  selector: 'users',
  templateUrl: './users.html'
})

export class UsersPage implements OnInit {
  ngOnInit() {
  }
  
}
