import { Component, OnInit  } from '@angular/core';

@Component({
  selector: 'home',
  templateUrl: './home.html'
})

export class HomePage implements OnInit {
  ngOnInit() {
  }
}
